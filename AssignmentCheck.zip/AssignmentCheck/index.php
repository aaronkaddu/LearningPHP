<!DOCTYPE html>
<html>
<head>
	<title>Assignment Check</title>

	<link rel="stylesheet" type="text/css" href="css/bootstrap.css">
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="css/bootstrap-theme.css">
	<link rel="stylesheet" type="text/css" href="css/bootstrap-theme.min.css">

	<style type="text/css">
		body{
			padding: 50px;
		}
	</style>
</head>
<body>

<div class="container_fluid">
	<div class="jumbotron">
		<h2 class="text-center">Assignment Checking For Students</h2>
	</div>
	<div class="row">
		<div class="col-md-2"></div>
		<div class="col-md-8">
			<form method="POST" action="index.php">
			  <div class="form-group">
			    <label for="testone">First Asignment:</label>
			    <textarea class="form-control" id="testone" name="testone"></textarea>
			  </div>
			  <div class="form-group">
			  	<label for="testtwo">Second Assignment</label>
			  	<textarea class="form-control" id="testtwo" name="testtwo"></textarea>
			  </div>
			  <button type="submit" name="submit" class="btn btn-default">Check For Similarity</button>
		</form>
		</div>
		<div class="col-md-4"></div>
	</div>
</div>

<?php 
	
	$sample1 = $_POST["testone"];
	$sample2 = $_POST["testtwo"];

	similar_text($sample1, $sample2, $result);

	echo "<br><br><strong>The Percentage is $result</strong> <br><br><br><hr>";

	if ($result >= 90) {
		echo "Student Copied";
	}elseif($result >= 80){
		echo "They shared Some Work";
	}elseif($result >= 70){
		echo "The Students May have done the work Together";
	}elseif ($result >= 50) {
		echo "The Students Got Work from The Same Source";
	} else {
		echo "Original Work";
	}
?>
</body>
</html>